# deleting all of a small tree
./test4 < tree3
