// COMP1521 19t2 ... Assignment 2: heap management system

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "myHeap.h"

/** minimum total space for heap */
#define MIN_HEAP 4096
/** minimum amount of space for a free Chunk (excludes Header) */
#define MIN_CHUNK 32


#define ALLOC 0x55555555
#define FREE  0xAAAAAAAA

/// Types:

typedef unsigned int  uint;
typedef unsigned char byte;

typedef uintptr_t     addr; // an address as a numeric type

/** The header for a chunk. */
typedef struct header {
	uint status;    /**< the chunk's status -- ALLOC or FREE */
	uint size;      /**< number of bytes, including header */
	byte data[];    /**< the chunk's data -- not interesting to us */
} header;

/** The heap's state */
struct heap {
	void  *heapMem;     /**< space allocated for Heap */
	uint   heapSize;    /**< number of bytes in heapMem */
	void **freeList;    /**< array of pointers to free chunks */
	uint   freeElems;   /**< number of elements in freeList[] */
	uint   nFree;       /**< number of free chunks */
};


/// Variables:

/** The heap proper. */
static struct heap Heap;


/// Functions:

static addr heapMaxAddr (void);


/** Initialise the Heap. */
int initHeap (int size)
{
    // get the correct size
	int n = size;
	if (n <= MIN_HEAP) {
		n = MIN_HEAP;
	} else if (n % 4 != 0) {
		n = (n / 4 + 1) * 4;
	}
	Heap.heapSize = n;
	Heap.heapMem = malloc(n);
	// if malloc failed
	if (Heap.heapMem == NULL)	return -1;
	header *heapHeader = Heap.heapMem;
	heapHeader->status = FREE;
	heapHeader->size = Heap.heapSize;

	Heap.freeElems = n / MIN_CHUNK;
	Heap.freeList = malloc(sizeof(void *) * Heap.freeElems);
	// if malloc failed then return -1
	if (Heap.freeList == NULL)	return -1;
	Heap.freeList[0] = Heap.heapMem;
	Heap.nFree = 1;

	return 0; // this just keeps the compiler quiet
}

/** Release resources associated with the heap. */
void freeHeap (void)
{
	free (Heap.heapMem);
	free (Heap.freeList);
}

/** Allocate a chunk of memory large enough to store `size' bytes. */
void *myMalloc (int size)
{
    // if the size is invalid 
	if (size < 1) {
		return NULL;
	}
	int headersize = sizeof(header);
	// make size to be the multiple of 4
	if (size % 4 != 0) {
		size = (size / 4 + 1) * 4; 
	}
	int totalsize = size + headersize;
	// find the smallest possible chunk
	int min = -1;

	for (int i = 0; i < Heap.nFree; i++) {
		header * curr = (header *)Heap.freeList[i];
		if (min == -1 && curr->size >= totalsize) {
			min = i;
			continue;
		}
		header * currmin = (header *) Heap.freeList[min];
		if (curr->size >= totalsize && curr->size < currmin->size) {
			min = i;
		}
	}
	// if not found return -1
	if (min == -1) return NULL;

	// the current chunk is less or equal to the size
	header *curr = (header *) Heap.freeList[min];
	curr->status = ALLOC;
	if (curr->size <= totalsize + MIN_CHUNK) {
		// delete the chunk from the freeList
		for (int i = min; i < Heap.nFree - 1; i++) {
			Heap.freeList[i] = Heap.freeList[i + 1];
		}
		Heap.nFree --;
		return (void *) (curr->data);
	} else {
		// split the chunk
		int prevsize = curr->size;
		curr->size = totalsize;
		addr newc = (addr) ((addr)curr + totalsize);
		header *newchunk = (header *)newc;
		newchunk->status = FREE;
		newchunk->size = prevsize - totalsize;
		// realign the position of freeList[min]
		Heap.freeList[min] = newchunk;
		return (void *)(curr->data);
	}
}

/** Deallocate a chunk of memory. */
void myFree (void *obj)
{
	if (obj == NULL) {
		fprintf(stderr, "Attempt to free unallocated chunk\n");
		exit(1);
	}
	int headersize = sizeof(header);
	addr targetaddr = (addr)((addr)obj - headersize);
	header *target = (header *)(targetaddr);
	// check the status of target
	if (target->status != ALLOC) {
		fprintf(stderr, "Attempt to free unallocated chunk\n");
		exit(1);
	}
	
	// set the status of target
	target->status = FREE;
	int i = 0;
	// get the position of the new free chunk in the freeList 
	while (i < Heap.nFree && (addr)Heap.freeList[i] < targetaddr) i++;
	
	// insert target into the freeList
	Heap.nFree ++;
	int target_pos = i;
	for (i = Heap.nFree - 1; i > target_pos; i--) {
	    Heap.freeList[i] = Heap.freeList[i - 1];
	}
	Heap.freeList[target_pos] = (void *) target;
	
	// merge all the possible free chunk
	i = 0;
	while ( i < Heap.nFree - 1) {
	    header *chunk = (header *)Heap.freeList[i]; 
	    // if the two free chunk are adjacent
	    if ((addr)chunk + chunk->size == (addr)Heap.freeList[i + 1]) {
	        chunk->size += ((header *)Heap.freeList[i + 1])->size;
	        // remove the next chunk from the freeList
	        for (int j = i + 1; j < Heap.nFree - 1; j++) {
	            Heap.freeList[j] = Heap.freeList[j + 1];
	        }
	        Heap.nFree --;
	        continue;
	    }
	    i++;
	    
	}

}

/** Return the first address beyond the range of the heap. */
static addr heapMaxAddr (void)
{
	return (addr) Heap.heapMem + Heap.heapSize;
}

/** Convert a pointer to an offset in the heap. */
int heapOffset (void *obj)
{
	addr objAddr = (addr) obj;
	addr heapMin = (addr) Heap.heapMem;
	addr heapMax =        heapMaxAddr ();
	if (obj == NULL || !(heapMin <= objAddr && objAddr < heapMax))
		return -1;
	else
		return (int) (objAddr - heapMin);
}

/** Dump the contents of the heap (for testing/debugging). */
void dumpHeap (void)
{
	int onRow = 0;

	// We iterate over the heap, chunk by chunk; we assume that the
	// first chunk is at the first location in the heap, and move along
	// by the size the chunk claims to be.
	addr curr = (addr) Heap.heapMem;
	while (curr < heapMaxAddr ()) {
		header *chunk = (header *) curr;
		char stat;
		switch (chunk->status) {
		case FREE:  stat = 'F'; break;
		case ALLOC: stat = 'A'; break;
		default:
			printf("%ld\n", curr);
			fprintf (
				stderr,
				"myHeap: corrupted heap: chunk status %08x\n",
				chunk->status
			);
			exit (1);
		}

		printf (
			"+%05d (%c,%5d)%c",
			heapOffset ((void *) curr),
			stat, chunk->size,
			(++onRow % 5 == 0) ? '\n' : ' '
		);

		curr += chunk->size;
	}

	if (onRow % 5 > 0)
		printf ("\n");
}
