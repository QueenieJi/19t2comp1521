"./$1" < tests/5.txt
