"./$1" < tests/2.txt
