echo "12" | 1521 spim -file fac1.s | sed -e 1d
