echo "-5" | 1521 spim -file fac2.s | sed -e 1d
