echo "20" | 1521 spim -file fac1.s | sed -e 1d
