// COMP1521 19t2 ... lab 03: where are the bits?
// watb.c: determine bit-field order

#include <stdio.h>
#include <stdlib.h>

struct _bit_fields {
	unsigned int a : 4;
	unsigned int b : 8;
	unsigned int c : 20;
};

int main (void)
{
	struct _bit_fields x = {0, 0, 3}; // struct _bit_fields x;
	                                  // x.a = 0;
	                                  // x.b = 0;
	                                  // x.c = 3;
	printf("a = 0000 b = 00000000 c = 00...0011\n");
    unsigned int *prtX = (unsigned int *) &x;
	unsigned int mask = 1;
	int i = 0;
	while (i < 32) {
	    if (i == 4 ||i == 12 ) printf (" ");
	    if ((*prtX & mask) > 0) {
	        printf("1");
	    } else {
	        printf("0");
	       
	    }
	    i++;
	    mask = mask << 1;
	}
    printf(" ");
	printf ("%zu\n", sizeof (x));

	return EXIT_SUCCESS;
}
