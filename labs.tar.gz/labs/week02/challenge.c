#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "BigNum.h"

void substractBigNums (BigNum bnA, BigNum bnB, BigNum *res)
{
    if (bnA.positive && !bnB.positive) {
        bnB.positive = 1;
        addBigNums(bnA, bnB, res);
        return;
    }
    if (!bnA.positive && bnB.positive) {
        bnB.positive = 0;
        addBigNums(bnA, bnB, res);
        return;
    }
    if (bnA.positive && bnB.positive) {
        int headA, headB;
	    for (headA = bnA.nbytes - 1;bnA.bytes[headA] == '0'; headA --) continue;
        for (headB = bnB.nbytes - 1;bnB.bytes[headB] == '0'; headB --) continue;
        int max;
        if (headA > headB) max = headA + 1;
        else max = headB + 1;
        initBigNum(res, max);
        int i = 0;
        headA++;

        headB++;
        printf("%d  %d\n", headA, headB);
        while (i < max) {
            int diff = 0;
            if (i < headA && i <headB) diff = bnA.bytes[i] - '0' -( bnB.bytes[i] - '0') + res->bytes[i] - '0';
            else if (i >= headA) diff = - (bnB.bytes[i] - '0')+ res->bytes[i] - '0';
            else if (i >= headB) diff = bnA.bytes[i] - '0'+ res->bytes[i] - '0';
            if (diff < 0) {
                if (i + 1 == headA) {
                    res->bytes[i] = 0 - diff + '0';
                    res->positive = 0;
                    break;
                } else {
                    res->bytes[i] = (diff + 10) + '0';
                    res->bytes[i + 1] = -'1';
                }
            } else {
                res->bytes[i] = diff + '0';
            }
            i++;
        }
    }
	

	return;
}

void multiplyBigNums (BigNum bnA, BigNum bnB, BigNum *res)
{
    int i = 0;
    BigNum temp;
    initBigNum(&temp, 20);
    while (i < bnB.nbytes) {
        int j;
        j = 0;
       // else j = 1;
        int tens = 1;
        for (int k = 0; k < i; k++) tens *= 10;
        while (j < (bnB.bytes[i] - '0') * tens) {
            addBigNums(temp, bnA, &temp);
           // showBigNum(temp);
            j++;
        }      
        i++;
    }
    *res = temp;
    if ((bnA.positive && !bnB.positive) || (!bnA.positive && bnB.positive)) {
        res->positive = 0;
    }
	return;
}

int main (int argc, char *argv[])
{
	BigNum num1; // first input number
	BigNum num2; // second input number
	BigNum sum;  // num1 + num2
	BigNum diff; // num1 - num2
    BigNum prod;
	if (argc < 3) {
		printf ("Usage: %s Num1 Num2\n", argv[0]);
		return 1;
	}

	// Initialise BigNum objects
	initBigNum (&num1, 20);
	initBigNum (&num2, 20);
	initBigNum (&sum, 20);
	initBigNum (&diff, 20);
    initBigNum (&prod, 20);
	// Extract values from cmd line args
	if (!scanBigNum (argv[1], &num1)) {
		printf ("First number invalid\n");
		return 1;
	}
	if (!scanBigNum (argv[2], &num2)) {
		printf ("Second number invalid\n");
		return 1;
	}

	//Add num1+num2, store result in sum
	// addBigNums (num1, num2, &sum);
	// printf ("Sum of "); showBigNum (num1);
	// printf ("\nand ");  showBigNum (num2);
	// printf ("\nis ");   showBigNum (sum);
	// printf ("\n");

	substractBigNums(num1, num2, &diff);
	printf ("Difference of "); showBigNum (num1);
	printf ("\nand ");  showBigNum (num2);
	printf ("\nis ");   showBigNum (diff);
	printf ("\n");

    // multiplyBigNums (num1, num2, &prod);
	// printf ("Product of "); showBigNum (num1);
	// printf ("\nand ");  showBigNum (num2);
	// printf ("\nis ");   showBigNum (prod);
	// printf ("\n");

	return EXIT_SUCCESS;
}
