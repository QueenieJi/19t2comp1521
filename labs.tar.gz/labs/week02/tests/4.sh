./add 123 hello
