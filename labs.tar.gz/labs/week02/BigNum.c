// BigNum.c ... LARGE positive integer values

#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "BigNum.h"

// Initialise a BigNum to N bytes, all zero
void initBigNum (BigNum *bn, int Nbytes)
{
	bn->bytes = malloc(sizeof(char) * Nbytes);
	bn->nbytes = Nbytes;
	bn->positive = 1;
	for (int i = 0; i < Nbytes; i++) bn->bytes[i] = '0';
	assert(bn != NULL);
	assert(bn->bytes != NULL);
	return;
}

// Add two BigNums and store result in a third BigNum
void addBigNums (BigNum bnA, BigNum bnB, BigNum *res)
{
	if ((bnA.positive && bnB.positive) || (!bnA.positive && !bnB.positive)) {
		int max;
		if (bnA.nbytes > bnB.nbytes) max = bnA.nbytes + 1;
		else max = bnB.nbytes + 1;
		if (max > res->nbytes) {
			res->bytes = realloc(res->bytes, max * sizeof (char));
			res->nbytes = max;
			for (int k = 0; k < res->nbytes; k++) res->bytes[k] = '0';
			res->positive = 1;
		}
		int i = 0;
		int len1 = bnA.nbytes;
		int len2 = bnB.nbytes;
		while (i < res->nbytes) {
			int sum = 0;
			if (i < len1 && i < len2) sum = bnA.bytes[i] - '0' + bnB.bytes[i] - '0' + res->bytes[i] - '0';
			else if (i >= len1 && i < len2) sum = bnB.bytes[i] - '0'+ res->bytes[i] - '0';
			else if (i >= len2 && i < len1) sum = bnA.bytes[i] - '0'+ res->bytes[i] - '0';
			else sum = res->bytes[i] - '0';
			if (sum > 9) {
				res->bytes[i] = (sum - 10) + '0';
				res->bytes[i + 1] = '1';
			} else {
				res->bytes[i] = sum + '0';
				
			}
			i++;
		}
		//printf("%c\n", res->bytes[max - 1]);
		if (!bnA.positive) res->positive = 0;
	}
	
	return;
}

// Set the value of a BigNum from a string of digits
// Returns 1 if it *was* a string of digits, 0 otherwise
int scanBigNum (char *s, BigNum *bn)
{
	int i = 0;
	while (isspace(s[i]) && i < strlen(s)) i++;
	if (i == strlen(s) || !isdigit(s[i])) return 0;
	int size = 0;
	while (isdigit(s[i]) && i < strlen(s)) {
		i++;
		size++;
	}

	if (size > bn->nbytes) {
		bn->bytes = realloc(bn->bytes, size * sizeof (char));
		bn->nbytes = size;
		for (int k = 0; k < bn->nbytes; k++) bn->bytes[k] = '0';
	}
	
	i--;
	int j = 0;
	while (j < size) {
		bn->bytes[j] = s[i];
		i--;
		j++;
	}
	return 1;
}

// Display a BigNum in decimal format
void showBigNum (BigNum bn)
{
	int head;
	for (head = bn.nbytes - 1;bn.bytes[head] == '0'; head --) continue;
	int i;
	if (bn.positive == 0) printf("-");
	for (i = head; i >= 0; i--) {
		printf("%c", bn.bytes[i]);
	}
	if (head == -1) {
		printf("0");
	}
	return;
}

