./vmsim 3 3 < tests/trace02 2>&1
