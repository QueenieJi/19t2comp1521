./vmsim 4 3 < tests/trace01 2>&1
