./vmsim 3 1 < tests/trace05 2>&1
