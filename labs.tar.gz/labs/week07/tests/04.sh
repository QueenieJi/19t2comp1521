./vmsim 4 3 < tests/trace02 2>&1
