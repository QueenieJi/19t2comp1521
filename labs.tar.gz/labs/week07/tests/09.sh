./vmsim 3 2 < tests/trace05 2>&1
