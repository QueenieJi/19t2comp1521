./vmsim 4 4 < tests/trace01 2>&1
