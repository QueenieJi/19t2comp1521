// matrix.h defines `N' and `m[N][N]'

#define N 3

int m[N][N] =
{
	{1, 0, 0},
	{0, 1, 0},
	{0, 0, 1}
};
