echo "12" | 1521 spim -file fac3.s | sed 1d
