// myls.c ... my very own "ls" implementation

#include <sys/types.h>
#include <sys/stat.h>

#include <dirent.h>
#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __linux__
# include <bsd/string.h>
#endif
#include <sysexits.h>
#include <unistd.h>

#define MAXDIRNAME 256
#define MAXFNAME 256
#define MAXNAME 24

char *rwxmode (mode_t, char *);
char *username (uid_t, char *);
char *groupname (gid_t, char *);

int main (int argc, char *argv[])
{
	// string buffers for various names
	char uname[MAXNAME+1]; // UNCOMMENT this line
	char gname[MAXNAME+1]; // UNCOMMENT this line
	char mode[MAXNAME+1]; // UNCOMMENT this line

	// collect the directory name, with "." as default
	char dirname[MAXDIRNAME] = ".";
	if (argc >= 2)
		strlcpy (dirname, argv[1], MAXDIRNAME);

	// check that the name really is a directory
	struct stat info;
	if (stat (dirname, &info) < 0)
		err (EX_OSERR, "%s", dirname);

	if (! S_ISDIR (info.st_mode)) {
		errno = ENOTDIR;
		err (EX_DATAERR, "%s", dirname);
	}

	// open the directory to start reading
	DIR *df; // UNCOMMENT this line
	df = opendir(dirname);


	// read directory entries
	struct dirent *entry;


	while ((entry = readdir(df)) != NULL) {
	    char buf[MAXFNAME+1];
		strcpy(buf, dirname);
		strcat(buf, "/");
		strcat(buf, entry->d_name);
//	    sprintf(buf,"%s/%s", dirname, entry->d_name);
	    if (entry->d_name[0] == '.') {
	        continue;
	    }
	    struct stat infoIn;
	    lstat(buf ,&infoIn);
	    printf("%s  %-8.8s %-8.8s  %8lld  %s\n",
	        rwxmode(infoIn.st_mode, mode),
	        username(infoIn.st_uid, uname),
	        groupname(infoIn.st_gid, gname),
	        (long long)(infoIn.st_size),
	        entry->d_name);
    }
	

	// finish up
	closedir(df);

	return EXIT_SUCCESS;
}

// convert octal mode to -rwxrwxrwx string
char *rwxmode (mode_t mode, char *str)
{
	//clear the input string 
    strcpy(str,"");
    // use the input mode to generate the string represent the file mode.
    // determine the file type
    switch (mode & S_IFMT){
        case S_IFREG:strcat(str,"-");break;
        case S_IFLNK:strcat(str,"l");break;
        case S_IFDIR:strcat(str,"d");break;
        // unknown file type for this iteration
        default: strcat(str,"?"); break;
    }

    // determine owner premission 
    strcat(str,((mode&S_IRUSR)?"r":"-"));
    strcat(str,((mode&S_IWUSR)?"w":"-"));
    strcat(str,((mode&S_IXUSR)?"x":"-"));
    
    // determine group premission 
    strcat(str,((mode&S_IRGRP)?"r":"-"));
    strcat(str,((mode&S_IWGRP)?"w":"-"));
    strcat(str,((mode&S_IXGRP)?"x":"-"));
    
    // determine others premission 
    strcat(str,((mode&S_IROTH)?"r":"-"));
    strcat(str,((mode&S_IWOTH)?"w":"-"));
    strcat(str,((mode&S_IXOTH)?"x":"-"));
      
    return str;
}

// convert user id to user name
char *username (uid_t uid, char *name)
{
	struct passwd *uinfo = getpwuid (uid);
	if (uinfo != NULL)
		snprintf (name, MAXNAME, "%s", uinfo->pw_name);
	else
		snprintf (name, MAXNAME, "%d?", (int) uid);
	return name;
}

// convert group id to group name
char *groupname (gid_t gid, char *name)
{
	struct group *ginfo = getgrgid (gid);
	if (ginfo != NULL)
		snprintf (name, MAXNAME, "%s", ginfo->gr_name);
	else
		snprintf (name, MAXNAME, "%d?", (int) gid);
	return name;
}
